#!/usr/bin/env bash

Rscript tree.R  Phy007AWWE_MYZPE.tree.txt

